import json
import psycopg2
import os

# RDS ayarları
RDS_HOST = os.environ['RDS_HOST']
RDS_USER = os.environ['RDS_USER']
RDS_PASSWORD = os.environ['RDS_PASSWORD']
RDS_DATABASE = os.environ['RDS_DATABASE']

def get_user_id(email):
    connection = psycopg2.connect(
        host=RDS_HOST,
        user=RDS_USER,
        password=RDS_PASSWORD,
        dbname=RDS_DATABASE
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT id FROM islerapp_customuser WHERE email = %s"
            cursor.execute(sql, (email,))
            result = cursor.fetchone()
            return result[0] if result else None
    finally:
        connection.close()

def get_bayi_ids(kullanici_id):
    connection = psycopg2.connect(
        host=RDS_HOST,
        user=RDS_USER,
        password=RDS_PASSWORD,
        dbname=RDS_DATABASE
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT bayi_id FROM islerapp_bayierisim WHERE kullanici_id = %s"
            cursor.execute(sql, (kullanici_id,))
            result = cursor.fetchall()
            return [row[0] for row in result]
    finally:
        connection.close()

def get_bayi_details(bayi_ids):
    if not bayi_ids:
        return []
    
    connection = psycopg2.connect(
        host=RDS_HOST,
        user=RDS_USER,
        password=RDS_PASSWORD,
        dbname=RDS_DATABASE
    )
    try:
        with connection.cursor() as cursor:
            format_strings = ','.join(['%s'] * len(bayi_ids))
            sql = f"SELECT * FROM islerapp_bayi WHERE id IN ({format_strings})"
            cursor.execute(sql, bayi_ids)
            result = cursor.fetchall()
            return [dict(zip([desc[0] for desc in cursor.description], row)) for row in result]
    finally:
        connection.close()

def lambda_handler(event, context):
    try:
        email = event.get('email')
        
        if not email:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Email is required'})
            }
        
        kullanici_id = get_user_id(email)
        
        if not kullanici_id:
            return {
                'statusCode': 404,
                'body': json.dumps({'error': 'User not found'})
            }
        
        bayi_ids = get_bayi_ids(kullanici_id)
        
        if not bayi_ids:
            return {
                'statusCode': 404,
                'body': json.dumps({'error': 'No bayi found for user'})
            }
        
        bayi_details = get_bayi_details(bayi_ids)
        
        return {
            'statusCode': 200,
            'body': json.dumps(bayi_details)
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
